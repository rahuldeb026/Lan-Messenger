# Lan-Messenger(frontend)

for details click [here](https://github.com/rjarman/Lan-Messenger)